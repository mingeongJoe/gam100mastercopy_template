URL of Project

https://editor.p5js.org/iamjoe0412@gmail.com/full/qD-scD9_p

Pac-man cooperated by Bandai Namco Entertainment

Team Basic
mingeong joe
Sunyoung Kim

Digipen ID
mingeong.joe
sunyoung.kim

player : should eat all the coins in map and should not be attackted by ghosts. it can only maintain past - direction, and no attack skills.

but, when player eat the big coins, ghosts turn to frightened mode, and player can avoid and attack the ghosts to go back.

3 ghosts algorithm

clyde : not strictly follow the player, but it's movement is kind of random.
pinky : follow the player's front tile.
blinky : follow the player's back.


up, down, left, right arrow : player's movement
enter : game menu change.