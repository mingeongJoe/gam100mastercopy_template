//gam100_mingeong.joe_pac-man
//pac-man
//GAM100
//2020 Fall
//Author : mingeong.joe
//All content © 2020 DigiPen (USA) Corporation, all rights reserved.



var GameStart = false;
var playerXs;
var playerYs;

//reverse
var eat = false;
let ftimer = 0;


var walls = [0, 45, 440, 7,
            0, 494, 440, 7,
            0, 45, 9, 145,
            433, 45, 9, 145,
            0, 325, 9, 175,
            433, 325, 9, 175,
            39, 82, 48, 28,//1
            117, 82, 65, 28,//2
            211, 50, 18, 60,//3
            260, 82, 65, 28,//4
            355, 82, 50, 28,//5
            39, 140, 48, 15,//6
            118, 140, 17, 103,//7
            165, 140, 111, 15,//8
            211, 155, 18, 44,//9
            308, 140, 17, 103,//10
            355, 140, 50, 15,//11
            -20, 185, 107, 58,//12
            118, 185, 64, 15,//13
            260, 185, 64, 15,//14
             
             190, 232, 64, 3,//14

            355, 185, 109, 58,//15
            -20, 273, 107, 58,//16
            118, 273, 17, 58,//17
            165, 316, 113, 15,//18
            308, 273, 17, 58,//19
            355, 273, 109, 58,//20
            39, 361, 48, 15,//21
            118, 361, 64, 15,//22
            211, 330, 18, 46,//23
            260, 361, 65, 15,//24
            355, 361, 48, 15,//25
            0, 406, 40, 13,//26
            70, 361, 17, 58,//27
            355, 361, 17, 58,//28
            165, 406, 113, 15,//29
            118, 406, 17, 58,//30
            308, 406, 17, 58,//31
            39, 449, 143, 15,//32
            260, 449, 143, 15,//33
            211, 418, 18, 46,//34
            402, 406, 40, 13,//35
            165, 230, 41, 7,//36
            236, 230, 42, 7,//37
            165, 230, 7, 50,//38
            271, 230, 7, 50,//39
            165, 279, 113, 7//40
            ]



var wall_location = []
var coins = []
var coin_location =[];

var Bcoins=  [];

var findcorner = [165, 479,
  65, 260,
  390, 260,
  60, 479,
  370, 479, 425,479]

var coins = []

  for (let i = 25; i < 210; i += 15.5) {
    coins.push(i, 68);
    coins.push(i,128)
   coins.push(i,348)
       coins.push(i,482)


  }

 for (let i = 250; i < 435; i += 15.5) {
    coins.push(i, 68);
    coins.push(i,128)
   coins.push(i,348)
       coins.push(i,482)


  }

for(let i = 82; i <= 117.5; i += 15.5){
  
  coins.push(25,i);
  coins.push(102.3,i);
    coins.push(195.3,i);
    coins.push(250.3,i);
 coins.push(343.3,i);
   coins.push(343.3,i);
   coins.push(420.3,i);

}


for(let i = 141; i <= 176.5; i += 15.5){
  
  coins.push(25,i);
  coins.push(102.3,i);
    coins.push(149,i);
    coins.push(296.7,i);
 coins.push(343.3,i);
   coins.push(343.3,i);
   coins.push(420.3,i);

}


for(let i = 363; i <= 397.5; i += 15.5){
  
  coins.push(25,i);
  coins.push(102.3,i);
    coins.push(196,i);
    coins.push(250.7,i);
 coins.push(343.3,i);
   coins.push(420.3,i);

}

for(let i = 407; i <= 441.5; i += 15.5){
  
     coins.push(58,i)
   coins.push(102,i);
      coins.push(150.7,i);
  
        coins.push(293,i);

      coins.push(343,i);
      coins.push(385,i);

}

for(let i =190; i<=330.5; i+=15.5){
  
  coins.push(102,i)
  coins.push(342,i)
}

for(let i =120; i<=195; i+=15.5){
  
  coins.push(i,394)

}

for(let i =40; i<=100; i+=15.5){
  
  coins.push(i,172)

}

for(let i =360; i<=420; i+=15.5){
  
  coins.push(i,172)

}


for(let i =166; i<=210; i+=15.5){
  
  coins.push(i,172)

}
for(let i =247; i<=287; i+=15.5){
  
  coins.push(i,172)

}


for(let i =265; i<=340; i+=15.5){
  
  coins.push(i,394)

}



for(let i = 437; i <= 471.5; i += 15.5){
  
  coins.push(25,i);
    coins.push(196,i);
    coins.push(249.7,i);
   coins.push(420.3,i);

}

function coinPush(x,y){
  
  for(let i =x; i<= x+30; i+=15.5){
    
    coins.push(i,y);
  }
}
var empty_up = true
var empty_down=true
var empty_left=true
var empty_right=true


var pac_img_stop=false

//cylde
  clydeStop=true

var clydeup 
var clydedown 
var clydeleft 
var clyderight 



let blinky_stop =false
let blinkyup 
let blinkydown 
let blinkyleft 
let blinkyright 


var score_p1 = 0;
var score_p2 = 0;
var highscore = 0;

var ghostTimer= 0;
var textTimer = 0;

var gamestate = ['menu', 'play', 'die', 'pause','ready'];


function setup() {
  createCanvas(600, 500);
    gamestate = 'menu';


  player = new Player(220, 391, 0, 0, 25);
  blinky = new Ghost2(220,215,25)
    pinky = new Ghost3(220,215,25)
   clyde = new Ghost(220,215,25)

  
  coinPush(42,394);
    coinPush(385,394);

    coinPush(355,438);
    coinPush(265,438);
    coinPush(165,438);

      coinPush(72,438);
      coinPush(217,482);
  coins.push(42,437)
  coins.push(402,437)
  
  
    Bcoins.push(new Bcoin(26,437))
  Bcoins.push(new Bcoin(25,97))
    Bcoins.push(new Bcoin(420,97))
    Bcoins.push(new Bcoin(420,437))


  pinky.xspeed = -1.4
  blinky.xspeed = -1.4

  setInterval(timer,100)
  
  
  for(let i=0; i<walls.length - 1; i += 4 ){ 
    wall_location.push(new Wall(walls[i],walls[i+1], walls[i+2], walls[i+3] ));
  } 

  for(let i = 1; i < 430; i+=1 ){
    cornercheck(i,68,25);
  }
  for(let i = 2; i < 430; i+=1 ){
    cornercheck(i,125,25); 
  }
    for(let i = 2; i < 430; i+=1 ){
    cornercheck(i,168,25);
  }
  for(let i = 99; i < 430; i+=1 ){  
    cornercheck(i,215,25);
  }
    for(let i = 2; i < 200; i+=1 ){
    cornercheck(i,260,25);
  }  
  
   for(let i = 250; i < 430; i+=1 ){
    cornercheck(i,260,25);
  }  
                                    
  for(let i = 80; i < 430; i+=1 ){  // 수정 가능
    cornercheck(i,302,25);
  } 
  for(let i = 1; i < 430; i+=1 ){
    cornercheck(i,345,25);
  } 
  for(let i = 1; i < 430; i+=1 ){
    cornercheck(i,392,25);
  }
  for(let i = 1; i < 430; i+=1 ){
    cornercheck(i,435,25);
  } 
  for(let i = 1; i < 430; i+=1 ){
    cornercheck(i,479,25);
  }   
  
  

    for (let i = 0; i < coins.length - 1; i += 2) {
    coin_location.push(new coin(coins[i], coins[i + 1]));
  }
  
  
  
  for(let i =0; i <= coin_location.length -1; i++){
  
  if(coin_location[i].x >= player.x - 10 && coin_location[i].x <= player.x +10 && coin_location[i].y >= player.y +10 && coin_location[i].y <= player.y -10){
    
    coin_location.splice(i,1);
    
    
  }

}
  
  
}



function draw() {
  if(gamestate == 'menu'){
    background(0);
  }else if(gamestate == 'ready'){
           

  for (let w of wall_location) { 
    w.draw()
    
  }
    
 for (let c of coin_location){
    c.draw();
  }
    
    for (let b of Bcoins){
    b.draw();
  }
    
 if(textTimer > 0 && textTimer < 50){
      
      textSize(15);
      fill('blue');
      text("PLAYER", 195, 210);
      fill('yellow');
      text("READY!", 195, 300);
   
   circle(220, 391,35)
    }
    else if (textTimer == 50){
             
      gamestate = 'play'
             
             }
 
           }
  else if(gamestate == 'play'){
  background(0);
    
      empty_up=true
  empty_down=true  
  empty_left=true  
  empty_right=true  
  
    
 for (let c of coin_location){
    c.draw();
  }
    
        for (let b of Bcoins){
    b.draw();
  }
  
    if(ghostTimer >60){
    blinky_stop=false
 blinkyup = 1
 blinkydown =1
 blinkyleft =1
 blinkyright =1  
      
  blinky.draw();
  blinky.move();
  blinky.chase(blinkyup,blinkydown,blinkyleft,blinkyright,player.x,player.y) 
      
  player.catch(blinky.x,blinky.y,blinky.r/2,1)
      
    }
  if(ghostTimer > 150){
    
     pinkystop = false;   
 pinkyup =1;
pinkydown=1;
 pinkyleft=1;
 pinkyright=1;
  
     pinky.draw();
    pinky.move()
       pinky.chase(pinkyup,pinkydown,pinkyleft,pinkyright,player.x,player.y)
  player.catch(pinky.x,pinky.y,pinky.r/2,2)
  }
   if(ghostTimer > 200){
     
       clydeStop=false
  clydeup = 1
  clydedown =1
  clydeleft =1
  clyderight =1

clyde.draw();
  clyde.move();

    
    for(let w of wall_location){
      
        if (w.collision(clyde.x, clyde.y, clyde.r / 2)) {
      clyde.x = clyde.x - clyde.xspeed
      clyde.y = clyde.y - clyde.yspeed

      clyde.xspeed = 0
      clyde.yspeed = 0
      clydeStop=true
    }    
    if (w.collision(clyde.x, clyde.y - 25, clyde.r / 2)) {
      clydeup = 0
    }
    if (w.collision(clyde.x, clyde.y + 25, clyde.r / 2)) {
      clydedown = 0
    }
    if (w.collision(clyde.x - 25, clyde.y, clyde.r / 2)) {
      clydeleft =0
    }
    if (w.collision(clyde.x + 25, clyde.y, clyde.r / 2)) {
      clyderight=0
    }
    
  
      
    }
    
    
  if(clydeup + clydedown + clydeleft +clyderight>=3 || clydeStop == true){
    
    
    clyde.chase(clydeup,clydedown,clydeleft,clyderight,player.x,player.y)
  }  
     
       player.catch(clyde.x,clyde.y,clyde.r/2,3)
   }


   
  
  if(GameStart == false){
    player.move();
  }
  

  for (let w of wall_location) { 
    w.draw()
    
  }
  
    
    
    
    for(let i =0; i <= coin_location.length -1; i++){

 if(coin_location[i].eaten(player.x,player.y)){
    
    coin_location.splice(i,1)
    
    }

}
    
    for(let i =0; i <= Bcoins.length -1; i++){

 if(Bcoins[i].eaten(player.x,player.y)){
    
    Bcoins.splice(i,1)
   
   ftimer = 0;
   eat = true;
   blinky.f = true;
   pinky.f = true;
   clyde.f = true;
   
   
   
   
      }
    }   

    // reverse
    if(eat){
      
      if(blinky.f){
         if(blinky.xspeed == 1.4){
     blinky.xspeed = 0.5
     
   }
      if(blinky.xspeed == -1.4){
     blinky.xspeed = -0.5

   }
      if(blinky.yspeed == 1.4){
     blinky.yspeed = 0.5
     
   }
   
      if(blinky.yspeed == -1.4){
     blinky.yspeed = -0.5
     
   }
      
      }

          if(pinky.f){
  
       if(pinky.xspeed == 1.4){
     pinky.xspeed = 0.5
     
   }
      if(pinky.xspeed == -1.4){
     pinky.xspeed = -0.5

   }
      if(pinky.yspeed == 1.4){
     pinky.yspeed = 0.5
     
   }
   
      if(pinky.yspeed == -1.4){
     pinky.yspeed = -0.5
     
   }
      
      
          }
      
      
        if(clyde.f){
       if(clyde.xspeed == 1.4){
     clyde.xspeed = 0.5
     
   }
      if(clyde.xspeed == -1.4){
     clyde.xspeed = -0.5

   }
      if(clyde.yspeed == 1.4){
     clyde.yspeed = 0.5
     
   }
   
      if(clyde.yspeed == -1.4){
     clyde.yspeed = -0.5
     
   }
        }
      
      }    

    
if(ftimer == 80){
  
  eat = false;
  blinky.f = false;
pinky.f = false;
  clyde.f = false;
  
  
  ftimer =0;
  
}
  //game is done
    if(coin_location.length == 0 && Bcoins == 0){
      
      reset();
      
      
    }
    
    
  push()
    fill('yellow')
 circle(player.x,player.y-3,35)

  fill(0)

  pop()
  
  
  noStroke();
  fill(255); 
    
  }
  else if(gamestate == 'die'){
    player.x_s = 0;
    player.y_s = 0;
    fill('red');
    textAlign(CENTER)
    text("GAME  OVER", 225, 300);
  }
  else if(gamestate == 'pause'){
    player.x_s = 0;
    player.y_s = 0;
  
  }


}

function timer(){
  ghostTimer++
  if(gamestate == 'ready'){
  textTimer++;
    
  }
  
  if(gamestate == 'play' && eat){
    
    ftimer++;
  }
}

function keyPressed(){
  if(keyCode == 13&&gamestate == 'menu'){
     gamestate = 'ready';
  }else if(keyCode == 13&&gamestate == 'play'){
    playerXs = player.x_s;
    playerYs = player.y_s;
 
    gamestate = 'pause';
  }else if(keyCode == 13&&gamestate == 'pause'){
    gamestate = 'play';
    player.x_s=playerXs;
    player.y_s=playerYs;
   
  }
}




// ghost diredtion checking

 function cornercheck(x, y, r) {

    let empty_up = 1
    let empty_down = 1
    let empty_left = 1
    let empty_right = 1
    let f_stop = false

    for (let w of wall_location) { // walls------------------

      if (w.collision(x, y, r / 2)) {


        f_stop = true
      }
      if (w.collision(x, y, 10)) {

        f_stop = false
      }
      if (w.collision(x, y - 25, r / 2)) {

        empty_up = 0
      }
      if (w.collision(x, y + 25, r / 2)) {

        empty_down = 0
      }
      if (w.collision(x - 25, y, r / 2)) {

        empty_left = 0
      }
      if (w.collision(x + 25, y, r / 2)) {

        empty_right = 0
      }


    }
   
   

    if (empty_up + empty_down + empty_left + empty_right >= 3 || f_stop == true) {


      let testing = dist(findcorner[findcorner.length - 2], findcorner[findcorner.length - 1], x, y)
      if (testing >= 30) {

        findcorner.push(x, y)

      }

    }



  }
  
  
  
  function reset(){
    
    player.x = 220;
    player.y = 391;
    blinky.x = 220;
    blinky.y = 215;
    clyde.x = 220;
    clyde.y = 215;
    pinky.x = 220;
    pinky.y = 215;
    
    coin_location =[];
    Bcoins =[];
    
      

    for (let i = 0; i < coins.length - 1; i += 2) {
    coin_location.push(new coin(coins[i], coins[i + 1]));
  }
    
    
  }