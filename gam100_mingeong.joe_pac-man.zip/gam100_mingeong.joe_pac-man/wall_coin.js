//gam100_mingeong.joe_pac-man
//pac-man
//GAM100
//2020 Fall
//Author : mingeong.joe
//All content © 2020 DigiPen (USA) Corporation, all rights reserved.

class Wall{
  constructor(x,y,w,h){
    this.x= x;
    this.y = y;
    this.w = w
    this.h = h;
  }
  draw(){
    
    fill(150);
    noStroke();
     rect(this.x,this.y,this.w,this.h);
    fill(255);
    
    
  }
  
  collision(x,y,r){
   
    if(x+r > this.x && x-r < this.x+this.w && y+r > this.y && y-r < this.y + this.h ){               
      return true;
    }
   return false;    
  }
  
}

class coin{
  constructor(x,y){
    this.x = x;
    this.y = y;
  }
  draw(){
    fill('yellow')
    circle(this.x, this.y,5);
  }
   eaten(x,y){
  
  if(this.x+2.5 <= x+13 &&  this.x -2.5 >= x- 13 && this.y +2.5 <= y +13 && this.y -2.5 >= y -13  ){
  
  return true;
  }
  else{
  
  return false;
  }
  }
  
}


class Bcoin{
  constructor(x,y){
    this.x = x;
    this.y = y;
  }
  draw(){
    fill('yellow')
    noStroke()
    circle(this.x, this.y,10);
  }
   eaten(x,y){
  
  if(this.x+5 <= x+13 &&  this.x -5 >= x- 13 && this.y +5 <= y +13 && this.y -2.5 >= y -13  ){
  
  return true;
  }
  else{
  
  return false;
  }
  }
  
}
