//gam100_mingeong.joe_pac-man
//pac-man
//GAM100
//2020 Fall
//Author : mingeong.joe
//All content © 2020 DigiPen (USA) Corporation, all rights reserved.

class Ghost2 {
  constructor(x, y, r) {
    this.x = x;
    this.y = y;
    this.xspeed = 0;
    this.yspeed = 0;
    this.r = r;

    this.f = false;
    
    this.fill = 'red'


    this.past_dir = 'left' 

  }

  draw() {
    
    if(this.f){
      
      fill(255)
       noStroke();
    circle(this.x, this.y, this.r);
    fill(0);
    }
    else{
    fill(this.fill);
    noStroke();
    circle(this.x, this.y, this.r);
    fill(0);
    }
    
    
  }
  move() {
  
    this.x += this.xspeed;
    this.y += this.yspeed;

    
    if (this.x > 457) {
      this.x = -17
    }
    if (this.x < -18) {
      this.x = 455
    }

 


  }

  chase(up, down, left, right, player_x, player_y) {
    
//reverse mode
    if(eat && this.f){
      player_x =410-player.x
     player_y = 410-player.y
      
    }
    
    if(eat && this.f == false){
      
      
     player_x = 220;
    player_y= 215
      

    }


    for (let w of wall_location) { 

   
      if (w.collision(this.x, this.y, this.r / 2)) {
        this.x = this.x - this.xspeed
        this.y = this.y - this.yspeed

        this.xspeed = 0
        this.yspeed = 0
        blinky_stop = true
      }

      if (w.collision(this.x, this.y - 25, this.r / 2)) {

        blinkyup = 0
      }
      if (w.collision(this.x, this.y + 25, this.r / 2)) {

        blinkydown = 0
      }
      if (w.collision(this.x - 25, this.y, this.r / 2)) {

        blinkyleft = 0
      }
      if (w.collision(this.x + 25, this.y, this.r / 2)) {

        blinkyright = 0
      }


    } 


    if (blinkyup + blinkydown + blinkyleft + blinkyright >= 3 || blinky_stop == true) {

      let findx = 0
      let findy = 0
   let finding_point = true

      let check_dist = 1000

     
      let new_ways   = [0, 0, 0, 0, 0, 0, 0, 0] 
      
//find the closest corner
      
      for (let i = 0; i < findcorner.length - 2; i += 2) {

        if (check_dist >= dist(findcorner[i], findcorner[i + 1], this.x, this.y)) {
          check_dist = dist(findcorner[i], findcorner[i + 1], this.x, this.y)
          findx = findcorner[i]
          findy = findcorner[i + 1]

        }

      }

 
//cannot go it's past direction
      for(let index = 0; index<8;index +=2 ){
        let a =0
        finding_point=true
        
       if( this.past_dir == 'down'){
        new_ways[0] = -1000
        new_ways[1] = -1000  
      }
        if( this.past_dir == 'up'){
        new_ways[2] = -1000
        new_ways[3] = -1000  
      }
            if( this.past_dir == 'right'){
        new_ways[4] = -1000
        new_ways[5] = -1000  
      }
              if( this.past_dir == 'left'){
        new_ways[6] = -1000
        new_ways[7] = -1000  
      }   
        
  
        while(finding_point){
          
 var choose = [findx,findy-a,findy+a,findy, findx-a, findx+a]

          for (let w of wall_location) { 
            
            let x,y =0;

            //up
             if(index ==0){
              
              x= choose[0]
              y = choose[1]
            }
            //down
            if(index ==2){
              
              x= choose[0]
              y = choose[2]
              
            }//left
            if(index ==4){
              
              x= choose[4]
              y = choose[3]
              
            }//right
            if(index ==6){
              
              x= choose[5]
              y = choose[3]
              
            }
            
            
            if(w.collision(x,y,2)){
              //to know what direction is not allowed.
              
              new_ways[index] = -1000;
              new_ways[index] = -1000;
              
              finding_point = false;
            }

          }
   
          for (let i = 0; i < findcorner.length - 2; i += 2) {

            let distance_check = 0
            
            switch (index){
              case 0:   
                distance_check=dist(findcorner[i], findcorner[i + 1], choose[0], choose[1] )
                break;
              case 2:   
                distance_check=dist(findcorner[i], findcorner[i + 1], choose[0],choose[2] )
                break;
              case 4:   
                distance_check=dist(findcorner[i], findcorner[i + 1], choose[4], choose[3] )
                break;
              case 6:   
                distance_check=dist(findcorner[i], findcorner[i + 1],choose[5], choose[3] )
                break;                  
            }
            
            
            if (10 >= distance_check &&  0 !=dist(findx,findy,findcorner[i], findcorner[i + 1]) ) {
            
                new_ways[index] = findcorner[i]
                new_ways[index+1] = findcorner[i + 1]
                finding_point = false
                break
            }

          }
            
         //caanot find the cloest   
          a++
          if(a >100){
                new_ways[index] = -1000
                new_ways[index+1] = -1000
                finding_point = false
          }
            
        }
      
      }  
     
        
        let short_dist=[-1000,-1000,0]
        
           
     for(let i = 0; i<8;i +=2 ){    
        
       if( dist(new_ways[i],new_ways[i+1],player_x,player_y) <= dist(short_dist[0],short_dist[1],player_x,player_y)  ){
         short_dist[0]=new_ways[i]
         short_dist[1]=new_ways[i+1]
         short_dist[2]= i/2 +1
       }
       
     }    
        
//direction value
    switch( short_dist[2]){
      case 1:
          if(eat&& this.f == false){
              this.xspeed=0
        this.yspeed=-2.8 
          
        }else{
        this.xspeed=0
        this.yspeed=-1.4 
        }
        this.past_dir = 'up'
        break
      case 2:
       if(eat&& this.f == false){
              this.xspeed=0
        this.yspeed= 2.8 
          
        }else{
        this.xspeed=0
        this.yspeed=1.4  
        }
        this.past_dir = 'down'
        break
      case 3:
       if(eat&& this.f == false){
              this.xspeed= -2.8 
        this.yspeed= 0
          
        }else{
        this.xspeed=-1.4
        this.yspeed=0      
        }
        this.past_dir = 'left'
        break
      case 4:
       if(eat&& this.f == false){
              this.xspeed= 2.8 
        this.yspeed= 0
          
        }else{
        this.xspeed=1.4
        this.yspeed=0    
        }
        this.past_dir = 'right'
        break       
    }
        
        
        


      } 




    }
      
  

  }


 