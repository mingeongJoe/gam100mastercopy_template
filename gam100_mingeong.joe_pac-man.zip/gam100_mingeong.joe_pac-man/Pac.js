

class Player {
  constructor(x, y, x_speed, y_speed, r) {
    this.x = x;
    this.y = y;
    this.x_s = x_speed;
    this.y_s = y_speed;
    this.r = r;
    

    
  }

  draw() {
    noFill();
    stroke(255);
    strokeWeight(1);
    circle(this.x, this.y, this.r);
    fill(0);
  }
  move() {
    this.x += this.x_s;
    this.y += this.y_s;

    if (this.x > 457) {
      this.x = -17
    }
    if (this.x < -18) {
      this.x = 455
    }
    
    for(let w of wall_location){
      
      if (w.collision(this.x, this.y, this.r / 2)) {
      this.x = this.x - this.x_s
      this.y = this.y - this.y_s

      this.x_s = 0
      this.y_s = 0

    }

    
    if (w.collision(this.x, this.y - 25, this.r / 2)) {
      empty_up = false
    }
    if (w.collision(this.x, this.y + 25, this.r / 2)) {
      empty_down = false
    }
    if (w.collision(this.x - 25, this.y, this.r / 2)) {
      empty_left = false
    }
    if (w.collision(this.x + 25, this.y, this.r / 2)) {
      empty_right = false
    }
    }
    
    
     if (keyIsPressed) {
      switch (keyCode){
        case UP_ARROW:
          if(empty_up){
          player.x_s = 0;
          player.y_s = -1.5;

            
          }
      
          break;
        case DOWN_ARROW:
          if(empty_down){
          player.x_s = 0;
          player.y_s = 1.5;

          }
          break;
        case LEFT_ARROW:
          if(empty_left){
          player.x_s = -1.5;
          player.y_s = 0;

          }
          break;
        case RIGHT_ARROW:
          if(empty_right){
          player.x_s = 1.5;
          player.y_s = 0;
  
          }
          break;
      
      }      
    }
  }

  //팩맨-고스트 충돌
  catch (x, y, r,type) {

    if (x + r-5 > this.x - this.r / 3 && x - r+5 < this.x + this.r / 3 && y + r-5 > this.y - this.r / 3 && y - r+5 < this.y + this.r / 3) {

      if(eat == false){
      gamestate = 'die';
      }
 else{

   switch(type){
     case 1:
          blinky.f = false;
       break;
       
  case 2:
          pinky.f = false;
       break;
          
  case 3:
         clyde.f = false;
       break;
          
       
   }

   
 }
    }


  }



}