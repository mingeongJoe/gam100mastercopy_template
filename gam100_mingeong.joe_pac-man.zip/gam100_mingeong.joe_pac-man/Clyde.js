//gam100_mingeong.joe_pac-man
//pac-man
//GAM100
//2020 Fall
//Author : mingeong.joe
//All content © 2020 DigiPen (USA) Corporation, all rights reserved.


//Cylde
class Ghost{
  constructor(x, y,r){
    this.x = x;
    this.y = y;
    this.xspeed = -1.4;
    this.yspeed = 0;
    this.r = r;

this.f = false;
    

  

  }
  
  draw(){
    
  if(this.f){
    
    fill(255)
    
  }
    fill('orange');

    noStroke();
    circle(this.x,this.y,this.r);
    fill(0);
    
  }
  move(){
    this.x += this.xspeed;
    this.y += this.yspeed; 
    
    if(this.x > 457 ){
      this.x = -17
    }
    if(this.x<-18){
      this.x=455 
    }
    



  }
  
  chase(up,down,left,right,playerx,playery){
     
     if(eat && this.f){
      playerx =410-player.x
     playery = 410-player.y
      
    }
    
    if(eat && this.f == false){
      
      
     playerx = 220;
    playery= 215
      

    }
    
    if(up == 1 && this.yspeed<=0){
      if(this.y >= playery){
        
          if(eat&& this.f == false){
              this.xspeed=0
        this.yspeed=-2.8 }
        else{
        this.xspeed=0
        this.yspeed=-1.4  
        }
        return
      }
    }
      
    if(down == 1 && this.yspeed >=0){
      if(this.y <= playery){
         if(eat&& this.f == false){
              this.xspeed=0
        this.yspeed=2.8 
         }else{
        this.xspeed=0
        this.yspeed=1.4
         }
        return
      }
    }    
      
    if(left == 1 && this.xspeed <=0){
      if(this.x >= playerx){
        
        if(eat&& this.f == false){
              this.xspeed= -2.8
        this.yspeed=0
         }else{
        this.xspeed=-1.4
        this.yspeed=0
         }
        return
      }
        
    }    
      
    if(right == 1 && this.xspeed>=0){
      if(this.x <= playerx){
        
        if(eat&& this.f == false){
              this.xspeed= 2.8
        this.yspeed=0
         }else{
        this.xspeed=1.4
        this.yspeed=0
         }
        return
      } 
    }
    //-------
     if(right == 1){
        if(eat&& this.f == false){
              this.xspeed= 2.8
        this.yspeed=0
         }else{
        this.xspeed=1.4
        this.yspeed=0
         }
        return
    }      
    if(left == 1){  
      if(eat&& this.f == false){
              this.xspeed= -2.8
        this.yspeed=0
         }else{
        this.xspeed=-1.4
        this.yspeed=0
         }
        return 
    }           
      
      
    if(up == 1){
       if(eat&& this.f == false){
              this.xspeed= 0
        this.yspeed= -2.8
         }else{
        this.xspeed=0
        this.yspeed=-1.4  
         }
        return
      
    }      
    if(down == 1){
      if(eat&& this.f == false){
              this.xspeed= 0
        this.yspeed= 2.8
         }else{
        this.xspeed=0
        this.yspeed=1.4
         }
        return     
    }              
  
  } 
    
}